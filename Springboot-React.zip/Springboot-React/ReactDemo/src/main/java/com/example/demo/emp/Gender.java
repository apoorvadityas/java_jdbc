package com.example.demo.emp;

public enum Gender {
	MALE, FEMALE
}
