package com.example.demo.mgr;

public enum Gender {
	MALE, FEMALE
}
